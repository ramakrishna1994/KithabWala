<?php
session_start();
session_unset();
/*session_start();
$_SESSION['emailid'] = 'rk@gmail.com';
$_SESSION['username'] = 'rk';*/
?>